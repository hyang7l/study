package kr.co.greenart.member.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import kr.co.greenart.member.model.dto.Member;


// RestController : @Controller + @ResponseBody
@RestController
@RequestMapping("/member")
public class MemberRestApi {
	
//	/member/id
//	/member/14 --> 14
	@GetMapping("/{id}")
	public ResponseEntity findMemberByName(@PathVariable("id") String id) {
		Member m = new Member();
		m.setMemberName("김재섭");
		
		return new ResponseEntity(m, HttpStatus.OK);
				
	}

}
