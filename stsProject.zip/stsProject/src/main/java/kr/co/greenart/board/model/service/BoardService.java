package kr.co.greenart.board.model.service;

import java.util.List;

import kr.co.greenart.board.model.dto.Board;
import kr.co.greenart.common.model.dto.PageInfo;

public interface BoardService {
	
	//전체 게시글 수 구하기
	//추상 메서드
	int selectListCount();
	
	
	//목록 불러오기
	List<Board> selectListAll(PageInfo pi);
	
	//글쓰기
	int insertBoard(Board board);

	//상세 페이지
	Board detailBoard(int idx);
	
	//조회수 증가
	int countBoard(Board board);
	
	//수정
	int updateBoard(Board bo);
	
	//삭제
	int deleteBoard(Board bo);
} 
