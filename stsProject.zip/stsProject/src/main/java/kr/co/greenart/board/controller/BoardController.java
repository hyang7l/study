package kr.co.greenart.board.controller;

import java.io.Console;
import java.lang.ProcessBuilder.Redirect;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;

import kr.co.greenart.board.model.dto.Board;
import kr.co.greenart.board.model.service.BoardServiceImpl;
import kr.co.greenart.common.model.dto.PageInfo;
import kr.co.greenart.common.template.Login;
import kr.co.greenart.common.template.Pagination;

@Controller
@RequestMapping("/board") // http://localhost/board
public class BoardController {

		// RequestMapping : get, post 요청 둘다 받고
		// GetMapping : get만 ( get : URL 정보 보임, 중요도 낮은 정보들 (EX: 검색, 페이지 이동)
		// PostMapping : post만 ( post : URL 정보 안보임, 네트워크 패킷 body 안에 데이터가 들어감, 중요한 정보들 ( 회원가입, 로그인, 결제 정보 등)
		
		@Autowired //객체 초기화 안해도 사용 가능하게 함
		private BoardServiceImpl boardService;
//		BoardServiceImpl boardService = new BoardServiceImpl; 와 같음
		
//		@Autowired
//		private Login loginCheck; //로그인 객체 생성 ( Login loginCheck = new login;
		
		@GetMapping("/list.do")
		public String boardList(@RequestParam(value = "cpage", defaultValue="1") int currentPage, 
											Model model, HttpSession session) {
			
			if(Login.loginCheck(session)) {
			
				//전체 게시글 수 구하기
				int listCount = boardService.selectListCount();
				//전체 페이지수 몇개까지 보여줄건지
				int pageLimit = 10;
				//한 페이지에 보여질 게시글 수
				int boardLimit = 15;
				
				//글 번호 뒤에서부터 출력해주는 변수
				int row = listCount - (currentPage-1) * boardLimit;
				
				
				
				// 페이징 로직 처리
				PageInfo pi = Pagination.getPageInfo(listCount, currentPage, pageLimit, boardLimit);
				
				//목록 불러오기
				List<Board> list = boardService.selectListAll(pi);
				
	// ----------------------------------------------------------------------------------------------
				//date 길이 잘라내기
				for(Board item : list) {
					// 한줄로 가능
					item.setIndate(item.getIndate().substring(0, 10));
	//-----------------------------------------------------------------------			
					// 저장 및 자르기 두줄로 가능
//					String indate = item.getIndate().substring(0, 10);
//					item.setIndate(indate);
	//-----------------------------------------------------------------------				
					
//					// 날짜 변수에 저장
//					String indate = item.getIndate();
//					
//					// 문자열 자르기
//					String subIndate = indate.substring(0, 10);
					
					
					// 문자열 자른 변수를 item 객체에 저장
//					item.setIndate(subIndate);
				}
	//-----------------------------------------------------------------------------------------------			
				
				//로그인 메시지
				String msg = (String) session.getAttribute("msg");
				String status = (String) session.getAttribute("status");
				
				model.addAttribute("list",list); // 객체 바인딩
				model.addAttribute("pi",pi);
				model.addAttribute("row",row);
				model.addAttribute("status",status);
				model.addAttribute("msg", msg);
				
				session.removeAttribute("msg");
				session.removeAttribute("status");
				
				System.out.println(list);
				
				return "board/boardList";
				//톰캣 재시작 후 -> localhost/board/list.do 접속
				
			} else {
				model.addAttribute("msg","잘못된 접근입니다");
				model.addAttribute("status", "error");
				return "member/login";
			}
			
		}
		
		@GetMapping("enrollForm.do")
		public String enrollForm() {
			return "board/boardEnroll";
		}
		
		@PostMapping("insert.do")
		public String insertBoard(Board board, HttpSession session) {
//			아래 한줄과 같음
//			String name = (String)session.getAttribute("membername");
//			board.setWriter(name);
			board.setWriter((String)session.getAttribute("memberName"));
			System.out.println("title : " + board.getTitle() );
			System.out.println("content : " + board.getContent());
			
			//result = 1
			//result = 0
			int result = boardService.insertBoard(board);
			
			
			if(result > 0) {
				return "redirect:/board/list.do";
			}else {
				return "common/errorPage";
			}
			
//			System.out.println(board.getTitle());
//			System.out.println(board.getContent());
//			return "";
		}
		
		@GetMapping("detail.do")
		public String detailBoard(@RequestParam(value = "boardIdx") int idx, Model model, HttpSession session) {
			//인터페이스 BoardService
			//BoardServiceImpl
			//BoardDao
			
			Board result = boardService.detailBoard(idx);
				
			if(!Objects.isNull(result)) {
				//조회수 증가
				int count = result.getCount()+1;
				result.setCount(count);
				result.setIdx(idx);
				boardService.countBoard(result);
				// 한줄
//				boardService.countBoard(result.getCount()+1);
				
//				교재에는 이렇게 
//				result.setContent(result.getContent()+1);
//				boardService.countBoard(result);
				
				
				model.addAttribute("detail", result);
				model.addAttribute("user", session.getAttribute("memberName"));
				
				return "board/boardDetail";
			}else {
//				원래는 에러페이지로 넘겨야함
				return "";
			}
		}
		
		@PostMapping("update.do")
		public String updateBoard(Board bo, HttpSession session) {
			int result = boardService.updateBoard(bo);
			
			if(result > 0) {
				session.setAttribute("msg", "수정 되었습니다.");
				session.setAttribute("status", "success");
				return "redirect:/board/list.do";
			} else {
				session.setAttribute("msg", "수정 실패에 했습니다.");
				session.setAttribute("status", "error");
				return "redirect:/board/list.do";
			}
		}
		
		
		@PostMapping("delete.do")
		public String deleteBoard(Board bo, HttpSession session) {
			int result = boardService.deleteBoard(bo);
			
			if(result > 0) {
				session.setAttribute("msg", "삭제 되었습니다.");
				session.setAttribute("status", "success");
				return "redirect:/board/list.do";
			}else {
				session.setAttribute("msg", "삭제 실패");
				session.setAttribute("status", "error");
				return "redirect:/board/list.do";
			}
		}
		
}
