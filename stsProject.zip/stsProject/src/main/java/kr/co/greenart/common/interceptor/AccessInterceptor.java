package kr.co.greenart.common.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.lang.Nullable;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;


// HandlerInterceptor-> ctrl + 마우스 왼클릭으로 97번부터 151까지 
public class AccessInterceptor implements HandlerInterceptor{
		
	public boolean preHandle(HttpServletRequest	 request, HttpServletResponse response, Object handler)
			throws Exception {

		
		// referer : http://localhost/
//		String referer = request.getHeader("referer");
//		
//		String requestURI = request.getRequestURI();
//		String serverAddress = request.getRequestURL().toString();
//		
//		System.out.println("referer : " + referer);
//		System.out.println("requestURI : " + requestURI);
//		System.out.println("serverAddress : " + serverAddress);
//		
//		// replace  = 문자열 자름
//		// serverAddress -> http://localhost/board/list.do,					requestURI -> /board/list.do
//		// requestURI를 동적으로 가져와서 문자열을 자르므로 							localServerAddress -> http://localhost
//		String localServerAddress = serverAddress.replace(requestURI, "");
//		
//		
//		
//		if(requestURI.equals("/free/detail.do") &&
//				(referer == null || !referer.startsWith(localServerAddress + "/free/list.do"))){
//			
//			response.sendRedirect("common/errorPage");
//			return false;
//		}
			
		
		return true;
	}

	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			@Nullable ModelAndView modelAndView) throws Exception {
	}

	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler,
			@Nullable Exception ex) throws Exception {
	}
	
}
