package kr.co.greenart.notice.model.service;

import java.util.List;

import kr.co.greenart.notice.model.dto.Notice;
import kr.co.greenart.common.model.dto.PageInfo;

public interface NoticeService {
	
	//전체 게시글 수 구하기
	//추상 메서드
	int selectListCount();
	
	
	//목록 불러오기
	List<Notice> selectListAll(PageInfo pi);
} 
