package kr.co.greenart.board.model.dao;

import java.util.List;

import org.apache.ibatis.session.RowBounds;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.stereotype.Repository;

import kr.co.greenart.board.model.dto.Board;
import kr.co.greenart.common.model.dto.PageInfo;

@Repository
public class BoardDao {

	public int selectListCount(SqlSessionTemplate sqlSession) {
		return sqlSession.selectOne("boardMapper.selectListCount");
	}
	
	public List<Board> selectListAll(SqlSessionTemplate sqlSession, PageInfo pi){
		
		int offset = (pi.getCurrentPage()-1) * pi.getBoardLimit();
		
		RowBounds rowBounds = new RowBounds(offset, pi.getBoardLimit());		
		
		return sqlSession.selectList("boardMapper.selectListAll", null, rowBounds);
	}

	public int inseertBoard(SqlSessionTemplate sqlSession, Board board) {
		
		return sqlSession.insert("boardMapper.insertBoard",board);
	}

	public Board detailBoard(SqlSessionTemplate sqlSession, int idx) {
	
		return sqlSession.selectOne("boardMapper.detailBoard",idx);
	}
	
	public int countBoard(SqlSessionTemplate sqlSeesion, Board board) {
		return sqlSeesion.update("boardMapper.countBoard", board);
	}
	
	public int updateBoard(SqlSessionTemplate sqlSession, Board bo) {
		return sqlSession.update("boardMapper.updateBoard",bo);
	}
	
	public int deleteBoard(SqlSessionTemplate sqlSession, Board bo) {
		return sqlSession.delete("boardMapper.deleteBoard",bo);
	} 
}
