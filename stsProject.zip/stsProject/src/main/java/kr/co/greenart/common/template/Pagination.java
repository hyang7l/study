package kr.co.greenart.common.template;

import kr.co.greenart.common.model.dto.PageInfo;

public class Pagination {
	
	public static PageInfo getPageInfo(int listCount, int currentPage,
			int pageLimit, int boardLimit) {
		
		// lintCount : 40
		// boardLimit : 15
		// 40.0 / 15.0 = 2.66666...
		// math.ceil( 반올림함 ) : 3 출력 
		int maxPage = (int)(Math.ceil(((double)listCount/boardLimit)));
		
		// currenPage = 16
		// pageLimit = 10
		// (currenPage -1 ) : 15
		// (currenPage -1 ) / pageLimit 
		//=>  15			/ 	10		= 1
		// (currentPage -1) / pageLimit * pageLimit 
		//=>  15			/ 	10		*	10		= 1 x 10 + 1
		//	11, 21, 31 이런식으로 출력 
		int startPage = (currentPage -1) / pageLimit * pageLimit +1;
		
		//				11		+	10		-1	: 	20
		//				41		+	10		-1	:	50
		int endPage = startPage + pageLimit -1;
		
		
		if(endPage > maxPage) {
			endPage = maxPage;
		}
		
		return new PageInfo(listCount, currentPage, pageLimit,
				boardLimit, boardLimit, maxPage, startPage, endPage);
	}
}