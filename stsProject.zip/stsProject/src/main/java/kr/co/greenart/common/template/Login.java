package kr.co.greenart.common.template;

import javax.servlet.http.HttpSession;

public class Login {
	
	public static boolean loginCheck(HttpSession session) {
		Integer memberIdx = (Integer) session.getAttribute("memberIdx");
		
		if(memberIdx == null) {

			return false;
			
		}else {
			
			return true;
			
		}
	}
}
