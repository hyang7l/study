package kr.co.greenart.free.controller;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Objects;
import java.util.Random;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import kr.co.greenart.common.controller.DataValidationController;
import kr.co.greenart.common.controller.SessionManageController;
import kr.co.greenart.common.controller.UploadFileController;
import kr.co.greenart.common.model.dto.PageInfo;
import kr.co.greenart.common.template.Pagination;
import kr.co.greenart.free.model.dto.Free;
import kr.co.greenart.free.model.service.FreeServiceImpl;

@Controller
@RequestMapping("/free") 
public class FreeController {
	
	//업로드 경로 ( \\두개 쓰는 이유는 escape문 될까봐, 특수 기능이 아닌 문자열 그자체로 의미 부여하기 위해 )
	public static final String UPLOAD_PATH = "C:\\Users\\GR803\\Documents\\workspace-sts-3.9.18.RELEASE\\stsProject\\src\\main\\webapp\\resources\\upload\\";
	
	@Autowired
	private FreeServiceImpl freeService;
	
	@Autowired //객체 생성 안해도 자동으로 만들어주는 스프링 기능
	private DataValidationController dataValidation;
	
	@Autowired
	private SessionManageController sessionManage;
	
	@Autowired
	private UploadFileController uploadFile;
	
	@GetMapping("/list.do")
	public String freeList(@RequestParam(value="searchTxt", defaultValue="") String searchTxt,
							@RequestParam(value = "cpage", defaultValue = "1") int currentPage, 
							Model model,
							HttpSession session) {
		// 전체 게시글 수 구하기
		int listCount = freeService.selectListCount(searchTxt);                                                             
		
		// 보여질 페이지 수
		int pageLimit = 10;
		
		// 한 페이지에 보여질 게시글 수
		int boardLimit = 15;
		
		// 글 번호 뒤에서부터 출력해주는 변수
		int row = listCount - (currentPage-1) * boardLimit;
		
		// 페이징 로직 처리
		PageInfo pi = Pagination.getPageInfo(listCount, currentPage, pageLimit, boardLimit);
		
		// 목록 불러오기
		List<Free> list = freeService.selectListAll(pi, searchTxt);
		
		for(Free item : list) {
			item.setCreateDate(item.getCreateDate().substring(0, 10));
			// 추가
			if(item.getCategory().equals("chat")) {
				item.setCategory("잡담");
			} else if(item.getCategory().equals("information")) {
				item.setCategory("정보");
			} else if(item.getCategory().equals("share")) {
				item.setCategory("공유");
			} 
		}
		
		// 로그인 메시지
		String msg = (String) session.getAttribute("msg");
		String status = (String) session.getAttribute("status");
		
		model.addAttribute("list", list); // 객체 바인딩
		model.addAttribute("pi", pi);
		model.addAttribute("row", row);
		model.addAttribute("msg", msg);
		model.addAttribute("status", status);
		
		session.removeAttribute("msg");
		session.removeAttribute("status");
		
		return "free/freeList";
	}
	
	@GetMapping("enrollForm.do")
	public String enrollForm(Model model, 
							HttpSession session, 
							HttpServletRequest request) {
		
		
		//String referer = request.getHeader("referer");
		//if(referer == null || ! referer.startsWith("http://localhost/free/list.do")) {
			//return "common/errorPage";
		//}
		
		model.addAttribute("msg",(String)session.getAttribute("msg"));
		model.addAttribute("status",(String)session.getAttribute("status"));
		
		session.removeAttribute("msg");
		session.removeAttribute("status");
		
		return "free/freeEnroll";
	}
	
	@PostMapping("insert.do")
	public String insertFree(MultipartFile upload,
							Free free, 
							HttpSession session) throws IllegalStateException, IOException {
		
		
		free.setWriter((String) session.getAttribute("memberName"));
		System.out.println(free.getCategory());
		
		//
		free = uploadFile.uploadFile(upload, free);
		
		
		boolean titleLength = dataValidation.LanguageCheck(free.getTitle());
		boolean contentLength = dataValidation.ContentLanguageCheck(free.getContent());
		boolean titleNullCheck = dataValidation.nullCheck(free.getTitle());
		
		if(titleLength && contentLength && titleNullCheck) {
			int result = freeService.insertFree(free);
			
			if(result > 0) {
				return "redirect:/free/list.do";
			} else {
				return "common/errorPage";
			}
		}else if(! titleLength) {
			sessionManage.setSessionMessage("제목이 너무 깁니다", "error", session);
			//enrollform
			return "redirect:/free/enrollForm.do";
		}
		else if(! contentLength){
			session.setAttribute("msg", "내용이 너무 깁니다");
			session.setAttribute("status", "error");
			//enrollform
			return "redirect:/free/enrollForm.do";
		} else if(! titleNullCheck){
			session.setAttribute("msg", "제목을 입력 해주세요");
			session.setAttribute("status", "error");
			//enrollform
			return "redirect:/free/enrollForm.do";
		} else {
			return "common/errorPage";
		}
	}
	
	@GetMapping("detail.do")
	public String detailFree(@RequestParam(value="freeIdx") int idx,
							  Model model,
							  HttpSession session) {
		Free result = freeService.detailFree(idx);
		
		if(!Objects.isNull(result)) {
			int count = result.getViews()+1;
			result.setViews(count);
			result.setIdx(idx);
			
			// 추가
			result.setCreateDate(result.getCreateDate().substring(0, 10));

			freeService.countFree(result);
			
			model.addAttribute("detail", result);
			model.addAttribute("user", session.getAttribute("memberName"));
			return "free/freeDetail";
		} else {
			// 원래는 에러페이지로 넘겨야함
			return "";
		}
	}
	
	@PostMapping("update.do")
	public String updateFree(MultipartFile upload, Free free, HttpSession session,
							@RequestParam(value = "idx") int idx) {
		free.setWriter((String)session.getAttribute("memberName"));
		free.setIdx(idx);
		
		//사용자가 파일 업로드 했을 때 : 새로운 정보 업데이트
		if(!upload.isEmpty()) {
			
			try {
				
				uploadFile.deleteFile(upload, free);
				
				free = uploadFile.uploadFile(upload, free);
			
			} catch (IllegalStateException e) {
				
				e.printStackTrace();
			} catch (IOException e) {
				
				e.printStackTrace();
			}
			
			int result = freeService.updateUploadFree(free);
			
			if(result > 0) {
				session.setAttribute("msg", "수정 되었습니다.");
				session.setAttribute("status", "success");
				return "redirect:/free/list.do";
			} else {
				session.setAttribute("msg", "수정에 실패했습니다.");
				session.setAttribute("status", "error");
				return "redirect:/free/list.do";
			}
			//파일 업로드 안했을때 : 기존 업로드 정보 유지
		} else if(upload.isEmpty()){

			int result = freeService.updateFree(free);
			
			if(result > 0) {
				session.setAttribute("msg", "수정 되었습니다.");
				session.setAttribute("status", "success");
				return "redirect:/free/list.do";
			} else {
				session.setAttribute("msg", "수정에 실패했습니다.");
				session.setAttribute("status", "error");
				return "redirect:/free/list.do";
			}
		} else {
			session.setAttribute("msg", "잘못된 접근입니다.");
			session.setAttribute("status", "error");
			return "redirect:/free/list.do";
		}
	}
	
	@PostMapping("delete.do")
	public String deleteFree(MultipartFile upload,
							// dto랑 다를 경우 @RequestParam(value = "idx") int idx 해서 비교해야함
							@RequestParam(value = "idx") int idx, 
							Free free, HttpSession session) throws IllegalStateException, IOException {
		free.setWriter((String)session.getAttribute("memberName"));
		
		uploadFile.deleteFile(upload, free);
		
		int result = freeService.deleteFree(free);
		
		if(result > 0) {
			session.setAttribute("msg", "삭제 되었습니다.");
			session.setAttribute("status", "success");
			return "redirect:/free/list.do";
		} else {
			session.setAttribute("msg", "삭제에 실패했습니다.");
			session.setAttribute("status", "error");
			return "redirect:/free/list.do";
		}
	}
	
	
}


























