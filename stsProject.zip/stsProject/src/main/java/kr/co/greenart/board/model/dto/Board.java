package kr.co.greenart.board.model.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


// ctrl + shift + 0 > 자동 import
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Board {
	private int idx;
	private String title;
	
	private String content;
	private String writer;
	private String indate;
	private int count;
	
}
