package kr.co.greenart.notice.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import kr.co.greenart.notice.model.dto.Notice;
import kr.co.greenart.notice.model.service.NoticeServiceImpl;
import kr.co.greenart.common.model.dto.PageInfo;
import kr.co.greenart.common.template.Login;
import kr.co.greenart.common.template.Pagination;

@Controller
@RequestMapping("/notice") // http://localhost/notice
public class NoticeController {

		// RequestMapping : get, post 요청 둘다 받고
		// GetMapping : get만 ( get : URL 정보 보임, 중요도 낮은 정보들 (EX: 검색, 페이지 이동)
		// PostMapping : post만 ( post : URL 정보 안보임, 네트워크 패킷 body 안에 데이터가 들어감, 중요한 정보들 ( 회원가입, 로그인, 결제 정보 등)
		
		@Autowired
		private NoticeServiceImpl noticeService;
//		NoticeServiceImpl noticeService = new NoticeServiceImpl; 와 같음
		
//		@Autowired
//		private Login loginCheck; //로그인 객체 생성 ( Login loginCheck = new login;
		
		@GetMapping("/list.do")
		public String noticeList(@RequestParam(value = "cpage", defaultValue="1") int currentPage, 
											Model model, HttpSession session) {
			
			if(Login.loginCheck(session)) {
			
				//전체 게시글 수 구하기
				int listCount = noticeService.selectListCount();
				//전체 페이지수 몇개까지 보여줄건지
				int pageLimit = 10;
				//한 페이지에 보여질 게시글 수
				int noticeLimit = 15;
				
				//글 번호 뒤에서부터 출력해주는 변수
				int row = listCount - (currentPage-1) * noticeLimit;
				
				
				
				// 페이징 로직 처리
				PageInfo pi = Pagination.getPageInfo(listCount, currentPage, pageLimit, noticeLimit);
				
				//목록 불러오기
				List<Notice> list = noticeService.selectListAll(pi);
				
	// ----------------------------------------------------------------------------------------------
				//date 길이 잘라내기
				for(Notice item : list) {
					// 한줄로 가능
					item.setCreateDate(item.getCreateDate().substring(0, 10));
	//-----------------------------------------------------------------------			
					// 저장 및 자르기 두줄로 가능
//					String createDate = item.getCreateDate().substring(0, 10);
//					item.setCreatedate(createDate);
	//-----------------------------------------------------------------------				
					
//					// 날짜 변수에 저장
//					String createDate = item.getCreateDate();
//					
//					// 문자열 자르기
//					String subIndate = createDate.substring(0, 10);
					
					
					// 문자열 자른 변수를 item 객체에 저장
//					item.setCreatedate(subIndate);
				}
	//-----------------------------------------------------------------------------------------------			
				
				//로그인 메시지
				String msg = (String) session.getAttribute("msg");
				String status = (String) session.getAttribute("status");
				
				model.addAttribute("list",list); // 객체 바인딩
				model.addAttribute("pi",pi);
				model.addAttribute("row",row);
				model.addAttribute("status",status);
				model.addAttribute("msg", msg);
				
				session.removeAttribute("msg");
				session.removeAttribute("status");
				
				System.out.println(list);
				
				return "notice/noticeList";
				//톰캣 재시작 후 -> localhost/notice/list.do 접속
				
			} else {
				model.addAttribute("msg","잘못된 접근입니다");
				model.addAttribute("status", "error");
				return "member/login";
			}
			
		}
}
