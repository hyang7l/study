package kr.co.greenart.notice.model.dao;

import java.util.List;

import org.apache.ibatis.session.RowBounds;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.stereotype.Repository;

import kr.co.greenart.notice.model.dto.Notice;
import kr.co.greenart.common.model.dto.PageInfo;

@Repository
public class NoticeDao {

	public int selectListCount(SqlSessionTemplate sqlSession) {
		return sqlSession.selectOne("noticeMapper.selectListCount");
	}
	
	public List<Notice> selectListAll(SqlSessionTemplate sqlSession, PageInfo pi){
		
		int offset = (pi.getCurrentPage()-1) * pi.getNoticeLimit();
		
		RowBounds rowBounds = new RowBounds(offset, pi.getNoticeLimit());		
		
		return sqlSession.selectList("noticeMapper.selectListAll", null, rowBounds);
	}
}
