package kr.co.greenart.common.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.lang.Nullable;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;


// HandlerInterceptor -> ctrl + 클릭으로 97번줄 부터 끝까지 복붙
public class LoginInterceptor implements HandlerInterceptor{
	
		@Override
		public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
				throws Exception {
			
			//"http://localhost/" 로 입력했을 때 alert 안뜨도록 하는 코드
			//true 반환하여 컨트롤러 호출
//			String requestURL = request.getRequestURL().toString();
//			if(requestURL.equals("http://localhost/")) {
//				return true;
//			}
//			
//			HttpSession session = request.getSession();
//			Integer memberIdx = (Integer) session.getAttribute("memberIdx");
//			
//			//유저 로그인 유무 체크
//			if(memberIdx == null) {
//				response.sendRedirect(request.getContextPath() +  "/member/redirect.do");
//				
//				//컨트롤러 호출 안하도록 해주는거 : return false;
//				return false;
//			}
//			
//			// 컨트롤러 호출 하도록 해주는거 : return true; 
			return true;
		}
	
		@Override
		public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
				@Nullable ModelAndView modelAndView) throws Exception {
		}
	
		@Override
		public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler,
				@Nullable Exception ex) throws Exception {
		}

}
