package kr.co.greenart.common.controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Objects;
import java.util.Random;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.multipart.MultipartFile;

import kr.co.greenart.free.model.dto.Free;
import kr.co.greenart.free.model.service.FreeServiceImpl;

@Controller
public class UploadFileController {

	//업로드 경로 ( \\두개 쓰는 이유는 escape문 될까봐, 특수 기능이 아닌 문자열 그자체로 의미 부여하기 위해 )
	public static final String UPLOAD_PATH = "C:\\Users\\GR803\\Documents\\workspace-sts-3.9.18.RELEASE\\stsProject\\src\\main\\webapp\\resources\\upload\\";
	
	@Autowired
	private FreeServiceImpl freeService;
	
	
	public boolean deleteFile(MultipartFile upload, Free free) {
		free = freeService.detailFree(free.getIdx());
		if(!Objects.isNull(free)) {
			
			// C:\Users\GR803\Documents\workspace-sts-3.9.18.RELEASE\stsProject\src\main\webapp\resources
			File deleteFile  = new File(free.getUploadPath() + free.getUploadName());
			deleteFile.delete();
			return true;
		} else {
			return false;
		}
	}
	
	
	public Free uploadFile(MultipartFile upload,
							Free free) throws IllegalStateException, IOException {
		
		if(!upload.isEmpty()) {
			// 원본 파일명
			String originalNmae = upload.getOriginalFilename();
			
			// 확장자
			// 제목 없음.png -> .png
			String extension = originalNmae.substring(originalNmae.lastIndexOf("."));
			
			// 2023-07-06: 10:10:10 이런식으로 나옴
			LocalDateTime now = LocalDateTime.now();
			
			// 23	07	06	10	32	15
			// 년	원	일	시	분	초	이런식으로 가공
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyMMddHHmmss");
			String output = now.format(formatter);
			
			//랜덤 문자열 생성
			int length = 8; //문자열 길이
			//()은 삭제, 이유 : 서버에서 에러뜸
			//윈도우는 파일명에 안되는 문자 있으니 적용 하면 안됨
			String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz!@#$%^&";
			
			Random random = new Random();
			String randomString = random.ints(length, 0 , characters.length())
					.mapToObj(characters::charAt)
					.map(Object::toString)
					.collect(Collectors.joining());
			
			//			날짜	_	랜덤 문자열	확장자
			// 230706104224_akw@@!wn.png
			String fileName = (output + "_" + randomString + extension);
			
			//경로 + 변경된 파일명
			String filePathName = UPLOAD_PATH + fileName;
			
			// 서버에 파일 저장
			// no.file.path 입포트
			Path filePath = Paths.get(filePathName);
			upload.transferTo(filePath); // 빨간줄 떴을때 첫번째건 호출 한곳에서 에러 처리, try catch는 해당 부분에서
			
			free.setUploadPath(UPLOAD_PATH);
			free.setUploadOriginName(originalNmae);
			free.setUploadName(fileName);
		}
		
		return free;
		
	}
}
